package com.example.NotificationService.Entity;

public enum NotificationType {
    EMAIL, SMS
}
